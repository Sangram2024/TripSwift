import { Subjects } from "./subjects";
import { Types } from "mongoose";

interface ReservationData {
  _id?: Types.ObjectId;
  hotelName?: string;
  city?: string;
  state?: string;
  managerId?: Types.ObjectId;
  pin?: string;
  checkIn?: string;
  checkOut?: string;
  paymentMethod?: string;
  amount?: number;
  user?: UserData;
  paymentCard?: {
    cardHolderName?: string;
    cardNumber?: string;
  };
}

interface UserData {
  id?: Types.ObjectId;
  firstname?: string;
  lastname?: string;
  email?: string;
  gender?: "male" | "female" | "other";
  age?: number;
  points?: number;
  uid?: string;
  dob?: Date | string;
  phone?: number;
  country?: string;
  state?: string;
  city?: string;
  zipCode?: number;
  managerId?: Types.ObjectId;
}

interface IntegrationData {
  id?: string;
  username?: string;
  email?: string;
  role?: "ADMIN" | "USER" | "MANAGER";
  city?: string;
  state?: string;
  pin?: string;
  mobile?: string;
  description?: string;
  name?: string;
}

interface NftMetadataData {
  email?: string;
  points?: number;
  managerId?: Types.ObjectId;
  tier?: "Silver" | "Gold" | "Platinum";
}

interface TierData {
  name?: string;
  points?: number;
  rewards?: string[];
  manager?: Types.ObjectId;
}

export interface ReservationCreatedEvent {
  subject: Subjects.ReservationCreated;
  data: ReservationData;
}

export interface ReservationUpdatedEvent {
  subject: Subjects.ReservationUpdated;
  data: ReservationData;
}

export interface ReservationCancelledEvent {
  subject: Subjects.ReservationCancelled;
  data: ReservationData;
} //github.com/Cloud10-Loyality/cloud10LMS-shared

export interface IntegrationCreatedEvent {
  subject: Subjects.IntegrationCreated;
  data: IntegrationData;
}

export interface IntegrationUpdatedEvent {
  subject: Subjects.IntegrationUpdated;
  data: IntegrationData;
}

export interface IntegrationDeletedEvent {
  subject: Subjects.IntegrationDeleted;
  data: IntegrationData;
}

export interface UserCreatedEvent {
  subject: Subjects.UserCreated;
  data: UserData;
}

export interface UserUpdatedEvent {
  subject: Subjects.UserUpdated;
  data: UserData;
}

export interface UserDeletedEvent {
  subject: Subjects.UserDeleted;
  data: UserData;
}

export interface PointsCreatedEvent {
  subject: Subjects.PointsCreated;
  data: NftMetadataData;
}

export interface PointsUpdatedEvent {
  subject: Subjects.PointsUpdated;
  data: NftMetadataData;
}

export interface PointsDeletedEvent {
  subject: Subjects.PointsDeleted;
  data: NftMetadataData;
}

export interface TierCreatedEvent {
  subject: Subjects.TierCreated;
  data: TierData;
}

export interface TierUpdatedEvent {
  subject: Subjects.TierUpdated;
  data: TierData;
}

export interface TierDeletedEvent {
  subject: Subjects.TierDeleted;
  data: TierData;
}

export * from "./base-listener";
export * from "./base-publisher";
